# CampusHub — Phase 1

A student achievement, skills, and goals tracker with a working React frontend, a
real Express + SQLite backend, JWT authentication, and a rule-based recommendation
engine. This is **Phase 1** of the full platform spec: it implements a smaller set
of modules completely and correctly, rather than all 12 modules partially. See
**"What's not built yet"** at the bottom for the rest of the plan.

## Technologies used

- **Frontend:** React (JavaScript + JSX, no TypeScript), Vite, React Router
- **Backend:** Node.js, Express (plain JavaScript)
- **Database:** SQLite via `better-sqlite3` (a single local file, no server to install)
- **Auth:** JWT tokens + bcrypt password hashing
- No Python, Java, PHP, Angular, Vue, Next.js, Spring, Django, Flask, Prisma, GraphQL, Docker, or Kubernetes anywhere in this project.

## Folder structure

```
campushub/
  backend/
    database/       db.js (schema) and seed.js (demo data)
    middleware/      auth.js (JWT check), errorHandler.js
    routes/          one file per resource, all thin
    controllers/     the actual request logic
    services/        profileCompletion.js, recommendationEngine.js
    utils/           validators.js, asyncHandler.js
    server.js
  frontend/
    src/
      api/            fetch wrapper + one file per resource
      context/         AuthContext.jsx (login state, token)
      components/
        layout/        Sidebar, Topbar, Layout, ProtectedRoute
        common/         Card, ProgressBar, Badge, Modal, EmptyState, etc.
      pages/           Login, Register, Dashboard, Profile, Achievements, Skills, Goals
  README.md
```

## How to install

You need [Node.js](https://nodejs.org) installed (LTS version, 18 or newer).

Open two terminal windows.

**Terminal 1 — backend:**
```
cd backend
npm install
copy .env.example .env
npm run dev
```
(On Mac/Linux use `cp .env.example .env` instead of `copy`.)

This starts the API at `http://localhost:5000` and automatically creates the
SQLite database file and seeds it with a demo account the first time it runs.

**Terminal 2 — frontend:**
```
cd frontend
npm install
npm run dev
```

This starts the app at `http://localhost:5173`. Open that URL in your browser.

## Demo login

```
Email:    demo@studentgrowth.local
Password: Demo123
```

It's pre-filled on the login screen, and comes with 5 achievements, 8 skills, and
3 goals already loaded so the dashboard isn't empty on first look.

You can also click "Register" to create your own account — it goes through the
real registration flow and starts with a blank profile.

## What each module actually does

- **Auth** — register/login/logout with hashed passwords and JWT sessions. Every
  API route except `/api/auth/*` requires a valid token.
- **Dashboard** — not hardcoded cards. It calls `GET /api/dashboard`, which pulls
  your real skills/achievements/goals from the database, computes your profile
  completion %, a growth score, your top skill gaps, and a "Your Next Steps" list
  from the rule-based recommendation engine (`backend/services/recommendationEngine.js`).
- **Profile** — editable fields (school, course, career goal, bio, links, etc.),
  with completion % calculated server-side from which fields are actually filled in.
- **Achievements** — full CRUD, category filter, search, sort by date, grouped
  into a year-by-year timeline.
- **Skills** — full CRUD, 1–5 level scale, automatically computes and highlights
  the largest skill gaps (target − current).
- **Goals** — full CRUD, status/type/priority, a slider to update progress inline,
  which also auto-updates status (0% → Not Started, 1–99% → In Progress, 100% → Completed).

The recommendation engine is genuinely rule-based (no AI call, no external
dependency) so the app works completely offline, matching the "must work without
an API key" requirement from the original spec.

## What's not built yet

The original spec asked for 12 modules plus AI agents, GitHub integration, and
notifications. Building all of that in one pass tends to produce code that
compiles but doesn't actually work end-to-end — so this phase covers a smaller
set completely, and the rest is a clear next phase rather than a half-built
stub:

- Resources / PYQ library
- Opportunities (internships, scholarships, hackathons)
- Study Planner (persisted, generated from skill gaps)
- Career Roadmap page (career selection → skill gap comparison)
- GitHub Insights (public API integration)
- LinkedIn Advisory checklist
- AI Growth Assistant + agent architecture (Career/Study/Project/Profile/Opportunity agents)
- Notification system
- Settings page

Each of these can be added the same way this phase was: a table in `db.js`, a
controller + route pair in the backend, and a page + API file in the frontend.
The existing structure (routes → controllers → services, common UI components)
is meant to make that additive rather than a rewrite.
