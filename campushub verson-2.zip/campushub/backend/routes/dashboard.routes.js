const express = require('express');
const asyncHandler = require('../utils/asyncHandler');
const { requireAuth } = require('../middleware/auth');
const { getDashboard } = require('../controllers/dashboard.controller');

const router = express.Router();
router.use(requireAuth);
router.get('/', asyncHandler(getDashboard));

module.exports = router;
