const express = require('express');
const asyncHandler = require('../utils/asyncHandler');
const { requireAuth } = require('../middleware/auth');
const {
  listAchievements, getAchievement, createAchievement, updateAchievement, deleteAchievement
} = require('../controllers/achievements.controller');

const router = express.Router();
router.use(requireAuth);

router.get('/', asyncHandler(listAchievements));
router.get('/:id', asyncHandler(getAchievement));
router.post('/', asyncHandler(createAchievement));
router.put('/:id', asyncHandler(updateAchievement));
router.delete('/:id', asyncHandler(deleteAchievement));

module.exports = router;
