const express = require('express');
const asyncHandler = require('../utils/asyncHandler');
const { requireAuth } = require('../middleware/auth');
const { getProfile, updateProfile } = require('../controllers/profile.controller');

const router = express.Router();
router.use(requireAuth);

router.get('/', asyncHandler(getProfile));
router.put('/', asyncHandler(updateProfile));

module.exports = router;
