const express = require('express');
const asyncHandler = require('../utils/asyncHandler');
const { requireAuth } = require('../middleware/auth');
const {
  listGoals, createGoal, updateGoal, deleteGoal
} = require('../controllers/goals.controller');

const router = express.Router();
router.use(requireAuth);

router.get('/', asyncHandler(listGoals));
router.post('/', asyncHandler(createGoal));
router.put('/:id', asyncHandler(updateGoal));
router.delete('/:id', asyncHandler(deleteGoal));

module.exports = router;
