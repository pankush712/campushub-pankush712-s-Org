const express = require('express');
const asyncHandler = require('../utils/asyncHandler');
const { requireAuth } = require('../middleware/auth');
const {
  listSkills, createSkill, updateSkill, deleteSkill
} = require('../controllers/skills.controller');

const router = express.Router();
router.use(requireAuth);

router.get('/', asyncHandler(listSkills));
router.post('/', asyncHandler(createSkill));
router.put('/:id', asyncHandler(updateSkill));
router.delete('/:id', asyncHandler(deleteSkill));

module.exports = router;
