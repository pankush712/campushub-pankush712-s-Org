require('dotenv').config();
const express = require('express');
const cors = require('cors');

const authRoutes = require('./routes/auth.routes');
const profileRoutes = require('./routes/profile.routes');
const achievementsRoutes = require('./routes/achievements.routes');
const skillsRoutes = require('./routes/skills.routes');
const goalsRoutes = require('./routes/goals.routes');
const dashboardRoutes = require('./routes/dashboard.routes');
const { notFoundHandler, errorHandler } = require('./middleware/errorHandler');
require('./database/db'); // ensures tables exist
const seed = require('./database/seed');

const app = express();

app.use(cors());
app.use(express.json());

app.get('/api/health', (req, res) => res.json({ status: 'ok' }));

app.use('/api/auth', authRoutes);
app.use('/api/profile', profileRoutes);
app.use('/api/achievements', achievementsRoutes);
app.use('/api/skills', skillsRoutes);
app.use('/api/goals', goalsRoutes);
app.use('/api/dashboard', dashboardRoutes);

app.use(notFoundHandler);
app.use(errorHandler);

const PORT = process.env.PORT || 5000;

// Auto-seed demo data on first run (safe to call repeatedly -- it checks first).
try {
  seed();
} catch (err) {
  console.error('Seed check failed:', err.message);
}

app.listen(PORT, () => {
  console.log(`Student Growth Platform API running on http://localhost:${PORT}`);
});
