const db = require('../database/db');
const { isNonEmptyString } = require('../utils/validators');

const CATEGORIES = ['Academic', 'Certification', 'Project', 'Competition', 'Hackathon', 'Internship', 'Volunteering', 'Extracurricular', 'Leadership', 'Other'];

function listAchievements(req, res) {
  const { category, search, sort } = req.query;
  let sql = 'SELECT * FROM achievements WHERE user_id = ?';
  const params = [req.userId];

  if (category && CATEGORIES.includes(category)) {
    sql += ' AND category = ?';
    params.push(category);
  }
  if (search) {
    sql += ' AND (title LIKE ? OR description LIKE ?)';
    params.push(`%${search}%`, `%${search}%`);
  }
  sql += sort === 'oldest' ? ' ORDER BY date ASC' : ' ORDER BY date DESC';

  const rows = db.prepare(sql).all(...params);
  res.json(rows);
}

function getAchievement(req, res) {
  const row = db.prepare('SELECT * FROM achievements WHERE id = ? AND user_id = ?').get(req.params.id, req.userId);
  if (!row) return res.status(404).json({ error: 'Achievement not found.' });
  res.json(row);
}

function createAchievement(req, res) {
  const { title, category, description, date, organization, evidence_link, certificate_link, skills } = req.body;

  if (!isNonEmptyString(title)) return res.status(400).json({ error: 'Title is required.' });
  if (!CATEGORIES.includes(category)) return res.status(400).json({ error: `Category must be one of: ${CATEGORIES.join(', ')}` });

  const result = db.prepare(`
    INSERT INTO achievements (user_id, title, category, description, date, organization, evidence_link, certificate_link, skills)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(req.userId, title.trim(), category, description || '', date || '', organization || '', evidence_link || '', certificate_link || '', skills || '');

  const row = db.prepare('SELECT * FROM achievements WHERE id = ?').get(result.lastInsertRowid);
  res.status(201).json(row);
}

function updateAchievement(req, res) {
  const existing = db.prepare('SELECT * FROM achievements WHERE id = ? AND user_id = ?').get(req.params.id, req.userId);
  if (!existing) return res.status(404).json({ error: 'Achievement not found.' });

  const { title, category, description, date, organization, evidence_link, certificate_link, skills } = req.body;
  if (category && !CATEGORIES.includes(category)) return res.status(400).json({ error: `Category must be one of: ${CATEGORIES.join(', ')}` });

  const merged = {
    title: title !== undefined ? title : existing.title,
    category: category !== undefined ? category : existing.category,
    description: description !== undefined ? description : existing.description,
    date: date !== undefined ? date : existing.date,
    organization: organization !== undefined ? organization : existing.organization,
    evidence_link: evidence_link !== undefined ? evidence_link : existing.evidence_link,
    certificate_link: certificate_link !== undefined ? certificate_link : existing.certificate_link,
    skills: skills !== undefined ? skills : existing.skills,
    id: existing.id
  };

  db.prepare(`
    UPDATE achievements SET title=@title, category=@category, description=@description, date=@date,
    organization=@organization, evidence_link=@evidence_link, certificate_link=@certificate_link, skills=@skills
    WHERE id=@id
  `).run(merged);

  const row = db.prepare('SELECT * FROM achievements WHERE id = ?').get(existing.id);
  res.json(row);
}

function deleteAchievement(req, res) {
  const existing = db.prepare('SELECT * FROM achievements WHERE id = ? AND user_id = ?').get(req.params.id, req.userId);
  if (!existing) return res.status(404).json({ error: 'Achievement not found.' });

  db.prepare('DELETE FROM achievements WHERE id = ?').run(existing.id);
  res.status(204).send();
}

module.exports = { listAchievements, getAchievement, createAchievement, updateAchievement, deleteAchievement, CATEGORIES };
