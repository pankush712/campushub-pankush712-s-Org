const db = require('../database/db');
const { isNonEmptyString, isInRange } = require('../utils/validators');

const CATEGORIES = ['Programming', 'Web Development', 'Data Structures', 'Database', 'Communication', 'Leadership', 'Problem Solving', 'Other'];

function listSkills(req, res) {
  const rows = db.prepare('SELECT * FROM skills WHERE user_id = ? ORDER BY (target_level - current_level) DESC').all(req.userId);
  res.json(rows);
}

function createSkill(req, res) {
  const { name, category, current_level, target_level, assessment_score } = req.body;

  if (!isNonEmptyString(name)) return res.status(400).json({ error: 'Skill name is required.' });
  if (!CATEGORIES.includes(category)) return res.status(400).json({ error: `Category must be one of: ${CATEGORIES.join(', ')}` });
  if (!isInRange(current_level, 1, 5)) return res.status(400).json({ error: 'Current level must be between 1 and 5.' });
  if (!isInRange(target_level, 1, 5)) return res.status(400).json({ error: 'Target level must be between 1 and 5.' });

  const result = db.prepare(`
    INSERT INTO skills (user_id, name, category, current_level, target_level, assessment_score)
    VALUES (?, ?, ?, ?, ?, ?)
  `).run(req.userId, name.trim(), category, Number(current_level), Number(target_level), Number(assessment_score) || 0);

  const row = db.prepare('SELECT * FROM skills WHERE id = ?').get(result.lastInsertRowid);
  res.status(201).json(row);
}

function updateSkill(req, res) {
  const existing = db.prepare('SELECT * FROM skills WHERE id = ? AND user_id = ?').get(req.params.id, req.userId);
  if (!existing) return res.status(404).json({ error: 'Skill not found.' });

  const { name, category, current_level, target_level, assessment_score } = req.body;
  if (category && !CATEGORIES.includes(category)) return res.status(400).json({ error: `Category must be one of: ${CATEGORIES.join(', ')}` });
  if (current_level !== undefined && !isInRange(current_level, 1, 5)) return res.status(400).json({ error: 'Current level must be between 1 and 5.' });
  if (target_level !== undefined && !isInRange(target_level, 1, 5)) return res.status(400).json({ error: 'Target level must be between 1 and 5.' });

  const merged = {
    name: name !== undefined ? name : existing.name,
    category: category !== undefined ? category : existing.category,
    current_level: current_level !== undefined ? Number(current_level) : existing.current_level,
    target_level: target_level !== undefined ? Number(target_level) : existing.target_level,
    assessment_score: assessment_score !== undefined ? Number(assessment_score) : existing.assessment_score,
    id: existing.id
  };

  db.prepare(`
    UPDATE skills SET name=@name, category=@category, current_level=@current_level, target_level=@target_level,
    assessment_score=@assessment_score, last_updated=datetime('now') WHERE id=@id
  `).run(merged);

  const row = db.prepare('SELECT * FROM skills WHERE id = ?').get(existing.id);
  res.json(row);
}

function deleteSkill(req, res) {
  const existing = db.prepare('SELECT * FROM skills WHERE id = ? AND user_id = ?').get(req.params.id, req.userId);
  if (!existing) return res.status(404).json({ error: 'Skill not found.' });

  db.prepare('DELETE FROM skills WHERE id = ?').run(existing.id);
  res.status(204).send();
}

module.exports = { listSkills, createSkill, updateSkill, deleteSkill, CATEGORIES };
