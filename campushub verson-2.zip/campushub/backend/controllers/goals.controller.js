const db = require('../database/db');
const { isNonEmptyString, isInRange } = require('../utils/validators');

const TYPES = ['Career', 'Academic', 'Technical', 'Personal', 'Project'];
const STATUSES = ['Not Started', 'In Progress', 'Completed'];
const PRIORITIES = ['Low', 'Medium', 'High'];

function listGoals(req, res) {
  const { status, type } = req.query;
  let sql = 'SELECT * FROM goals WHERE user_id = ?';
  const params = [req.userId];
  if (status && STATUSES.includes(status)) {
    sql += ' AND status = ?';
    params.push(status);
  }
  if (type && TYPES.includes(type)) {
    sql += ' AND type = ?';
    params.push(type);
  }
  sql += ' ORDER BY target_date ASC';
  res.json(db.prepare(sql).all(...params));
}

function createGoal(req, res) {
  const { title, type, description, target_date, priority, status, related_skills, progress } = req.body;

  if (!isNonEmptyString(title)) return res.status(400).json({ error: 'Title is required.' });
  if (!TYPES.includes(type)) return res.status(400).json({ error: `Type must be one of: ${TYPES.join(', ')}` });
  if (priority && !PRIORITIES.includes(priority)) return res.status(400).json({ error: `Priority must be one of: ${PRIORITIES.join(', ')}` });
  if (status && !STATUSES.includes(status)) return res.status(400).json({ error: `Status must be one of: ${STATUSES.join(', ')}` });

  const result = db.prepare(`
    INSERT INTO goals (user_id, title, type, description, target_date, priority, status, related_skills, progress)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
  `).run(req.userId, title.trim(), type, description || '', target_date || '', priority || 'Medium', status || 'Not Started', related_skills || '', Number(progress) || 0);

  res.status(201).json(db.prepare('SELECT * FROM goals WHERE id = ?').get(result.lastInsertRowid));
}

function updateGoal(req, res) {
  const existing = db.prepare('SELECT * FROM goals WHERE id = ? AND user_id = ?').get(req.params.id, req.userId);
  if (!existing) return res.status(404).json({ error: 'Goal not found.' });

  const { title, type, description, target_date, priority, status, related_skills, progress } = req.body;
  if (type && !TYPES.includes(type)) return res.status(400).json({ error: `Type must be one of: ${TYPES.join(', ')}` });
  if (priority && !PRIORITIES.includes(priority)) return res.status(400).json({ error: `Priority must be one of: ${PRIORITIES.join(', ')}` });
  if (status && !STATUSES.includes(status)) return res.status(400).json({ error: `Status must be one of: ${STATUSES.join(', ')}` });
  if (progress !== undefined && !isInRange(progress, 0, 100)) return res.status(400).json({ error: 'Progress must be between 0 and 100.' });

  const merged = {
    title: title !== undefined ? title : existing.title,
    type: type !== undefined ? type : existing.type,
    description: description !== undefined ? description : existing.description,
    target_date: target_date !== undefined ? target_date : existing.target_date,
    priority: priority !== undefined ? priority : existing.priority,
    status: status !== undefined ? status : existing.status,
    related_skills: related_skills !== undefined ? related_skills : existing.related_skills,
    progress: progress !== undefined ? Number(progress) : existing.progress,
    id: existing.id
  };

  db.prepare(`
    UPDATE goals SET title=@title, type=@type, description=@description, target_date=@target_date,
    priority=@priority, status=@status, related_skills=@related_skills, progress=@progress WHERE id=@id
  `).run(merged);

  res.json(db.prepare('SELECT * FROM goals WHERE id = ?').get(existing.id));
}

function deleteGoal(req, res) {
  const existing = db.prepare('SELECT * FROM goals WHERE id = ? AND user_id = ?').get(req.params.id, req.userId);
  if (!existing) return res.status(404).json({ error: 'Goal not found.' });
  db.prepare('DELETE FROM goals WHERE id = ?').run(existing.id);
  res.status(204).send();
}

module.exports = { listGoals, createGoal, updateGoal, deleteGoal, TYPES, STATUSES, PRIORITIES };
