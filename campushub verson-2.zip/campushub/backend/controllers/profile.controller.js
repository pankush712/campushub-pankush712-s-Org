const db = require('../database/db');
const { calculateProfileCompletion } = require('../services/profileCompletion');
const { isNonEmptyString } = require('../utils/validators');

function getProfile(req, res) {
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.userId);
  if (!user) return res.status(404).json({ error: 'User not found.' });

  const skillsCount = db.prepare('SELECT COUNT(*) as c FROM skills WHERE user_id = ?').get(req.userId).c;
  const achievementsCount = db.prepare('SELECT COUNT(*) as c FROM achievements WHERE user_id = ?').get(req.userId).c;
  const projectsCount = db
    .prepare("SELECT COUNT(*) as c FROM achievements WHERE user_id = ? AND category = 'Project'")
    .get(req.userId).c;

  const { password_hash, ...safeUser } = user;
  const completion = calculateProfileCompletion(user, skillsCount, achievementsCount, projectsCount);

  res.json({ ...safeUser, profileCompletion: completion });
}

function updateProfile(req, res) {
  const existing = db.prepare('SELECT * FROM users WHERE id = ?').get(req.userId);
  if (!existing) return res.status(404).json({ error: 'User not found.' });

  const fields = ['name', 'school', 'course', 'year', 'interests', 'career_goal', 'bio', 'location', 'linkedin_url', 'github_url'];
  const updates = {};
  for (const field of fields) {
    if (req.body[field] !== undefined) updates[field] = String(req.body[field]);
  }

  if (updates.name !== undefined && !isNonEmptyString(updates.name)) {
    return res.status(400).json({ error: 'Name cannot be empty.' });
  }

  const merged = { ...existing, ...updates };
  db.prepare(`
    UPDATE users SET name=@name, school=@school, course=@course, year=@year, interests=@interests,
    career_goal=@career_goal, bio=@bio, location=@location, linkedin_url=@linkedin_url, github_url=@github_url
    WHERE id=@id
  `).run(merged);

  const { password_hash, ...safeUser } = merged;
  res.json(safeUser);
}

module.exports = { getProfile, updateProfile };
