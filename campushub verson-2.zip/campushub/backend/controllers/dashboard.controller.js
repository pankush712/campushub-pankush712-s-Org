const db = require('../database/db');
const { calculateProfileCompletion } = require('../services/profileCompletion');
const { generateRecommendations, calculateGrowthScore, getSkillGaps } = require('../services/recommendationEngine');

function getDashboard(req, res) {
  const user = db.prepare('SELECT * FROM users WHERE id = ?').get(req.userId);
  if (!user) return res.status(404).json({ error: 'User not found.' });

  const skills = db.prepare('SELECT * FROM skills WHERE user_id = ?').all(req.userId);
  const achievements = db.prepare('SELECT * FROM achievements WHERE user_id = ? ORDER BY date DESC').all(req.userId);
  const goals = db.prepare('SELECT * FROM goals WHERE user_id = ?').all(req.userId);

  const skillsCount = skills.length;
  const achievementsCount = achievements.length;
  const projectsCount = achievements.filter((a) => a.category === 'Project').length;

  const profileCompletion = calculateProfileCompletion(user, skillsCount, achievementsCount, projectsCount);
  const growthScore = calculateGrowthScore({ profileCompletion, skills, goals, achievements });
  const recommendations = generateRecommendations({ user, skills, achievements, goals, profileCompletion });
  const skillGaps = getSkillGaps(skills).slice(0, 3);

  res.json({
    studentName: user.name,
    profileCompletion,
    growthScore,
    careerGoal: user.career_goal || 'Not set',
    skillProgress: skills.slice(0, 5),
    recentAchievements: achievements.slice(0, 3),
    upcomingGoals: goals.filter((g) => g.status !== 'Completed').slice(0, 3),
    topSkillGaps: skillGaps,
    nextSteps: recommendations,
    stats: {
      totalSkills: skillsCount,
      totalAchievements: achievementsCount,
      totalGoals: goals.length,
      goalsCompleted: goals.filter((g) => g.status === 'Completed').length
    }
  });
}

module.exports = { getDashboard };
