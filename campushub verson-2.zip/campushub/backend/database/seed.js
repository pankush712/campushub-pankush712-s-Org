const bcrypt = require('bcryptjs');
const db = require('./db');

const DEMO_EMAIL = 'demo@studentgrowth.local';
const DEMO_PASSWORD = 'Demo123';

function seed() {
  const existing = db.prepare('SELECT id FROM users WHERE email = ?').get(DEMO_EMAIL);
  if (existing) {
    console.log('Demo account already exists, skipping seed.');
    return;
  }

  const passwordHash = bcrypt.hashSync(DEMO_PASSWORD, 10);

  const insertUser = db.prepare(`
    INSERT INTO users (name, email, password_hash, school, course, year, interests, career_goal, bio, location, linkedin_url, github_url)
    VALUES (@name, @email, @password_hash, @school, @course, @year, @interests, @career_goal, @bio, @location, @linkedin_url, @github_url)
  `);

  const result = insertUser.run({
    name: 'Demo Student',
    email: DEMO_EMAIL,
    password_hash: passwordHash,
    school: 'ADGIPS (GGSIPU)',
    course: 'B.Tech Computer Science',
    year: '3rd Year',
    interests: 'Web Development, Open Source, UI Design',
    career_goal: 'Frontend Developer',
    bio: 'CS student building toward a career in frontend development.',
    location: 'New Delhi, India',
    linkedin_url: '',
    github_url: ''
  });

  const userId = result.lastInsertRowid;

  const insertAchievement = db.prepare(`
    INSERT INTO achievements (user_id, title, category, description, date, organization, evidence_link, certificate_link, skills)
    VALUES (@user_id, @title, @category, @description, @date, @organization, @evidence_link, @certificate_link, @skills)
  `);
  const achievements = [
    { title: 'Built a Personal Portfolio Website', category: 'Project', description: 'Responsive portfolio built with HTML, CSS and JavaScript.', date: '2025-03-10', organization: '', evidence_link: '', certificate_link: '', skills: 'HTML,CSS,JavaScript' },
    { title: 'Completed JavaScript Fundamentals Course', category: 'Certification', description: 'Online certification covering core JS concepts.', date: '2025-05-22', organization: 'Online Course Platform', evidence_link: '', certificate_link: '', skills: 'JavaScript' },
    { title: 'College Hackathon - 2nd Place', category: 'Hackathon', description: 'Built a campus event app in 24 hours with a team of 3.', date: '2025-09-14', organization: 'ADGIPS Tech Fest', evidence_link: '', certificate_link: '', skills: 'React,Teamwork' },
    { title: 'DBMS Coursework Excellence', category: 'Academic', description: 'Top scorer in DBMS semester coursework.', date: '2026-01-18', organization: 'ADGIPS', evidence_link: '', certificate_link: '', skills: 'SQL,Database' },
    { title: 'Open Source Contribution', category: 'Extracurricular', description: 'Fixed a documentation bug in a small open-source React library.', date: '2026-04-02', organization: 'GitHub', evidence_link: '', certificate_link: '', skills: 'Git,React' }
  ];
  for (const a of achievements) insertAchievement.run({ user_id: userId, ...a });

  const insertSkill = db.prepare(`
    INSERT INTO skills (user_id, name, category, current_level, target_level, assessment_score)
    VALUES (@user_id, @name, @category, @current_level, @target_level, @assessment_score)
  `);
  const skills = [
    { name: 'HTML', category: 'Web Development', current_level: 4, target_level: 5, assessment_score: 80 },
    { name: 'CSS', category: 'Web Development', current_level: 3, target_level: 5, assessment_score: 65 },
    { name: 'JavaScript', category: 'Programming', current_level: 3, target_level: 5, assessment_score: 60 },
    { name: 'React', category: 'Web Development', current_level: 2, target_level: 4, assessment_score: 45 },
    { name: 'Git', category: 'Other', current_level: 2, target_level: 4, assessment_score: 40 },
    { name: 'SQL', category: 'Database', current_level: 2, target_level: 3, assessment_score: 50 },
    { name: 'Data Structures', category: 'Data Structures', current_level: 3, target_level: 4, assessment_score: 55 },
    { name: 'Communication', category: 'Communication', current_level: 3, target_level: 4, assessment_score: 60 }
  ];
  for (const s of skills) insertSkill.run({ user_id: userId, ...s });

  const insertGoal = db.prepare(`
    INSERT INTO goals (user_id, title, type, description, target_date, priority, status, related_skills, progress)
    VALUES (@user_id, @title, @type, @description, @target_date, @priority, @status, @related_skills, @progress)
  `);
  const goals = [
    { title: 'Become a Frontend Developer', type: 'Career', description: 'Build strong React + JavaScript skills and a solid project portfolio.', target_date: '2027-06-01', priority: 'High', status: 'In Progress', related_skills: 'JavaScript,React,CSS', progress: 35 },
    { title: 'Finish DBMS Semester with Distinction', type: 'Academic', description: 'Maintain top grades in DBMS coursework and labs.', target_date: '2026-12-15', priority: 'Medium', status: 'In Progress', related_skills: 'SQL,Database', progress: 60 },
    { title: 'Ship a Full-Stack Project', type: 'Project', description: 'Design, build and deploy a complete full-stack application solo.', target_date: '2026-11-30', priority: 'High', status: 'Not Started', related_skills: 'React,JavaScript,Git', progress: 0 }
  ];
  for (const g of goals) insertGoal.run({ user_id: userId, ...g });

  console.log('Seed complete. Demo login: demo@studentgrowth.local / Demo123');
}

if (require.main === module) {
  seed();
}

module.exports = seed;
