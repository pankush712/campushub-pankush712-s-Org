function calculateProfileCompletion(user, skillsCount, achievementsCount, projectsCount) {
  let score = 0;

  const basicFields = [user.name, user.email, user.bio, user.location];
  const basicFilled = basicFields.filter((f) => f && f.trim().length > 0).length;
  score += (basicFilled / basicFields.length) * 20;

  const educationFields = [user.school, user.course, user.year];
  const educationFilled = educationFields.filter((f) => f && f.trim().length > 0).length;
  score += (educationFilled / educationFields.length) * 20;

  if (user.career_goal && user.career_goal.trim().length > 0) {
    score += 20;
  }

  score += Math.min(skillsCount / 3, 1) * 20;
  score += Math.min(achievementsCount / 3, 1) * 10;
  score += Math.min(projectsCount / 1, 1) * 10;

  return Math.round(score);
}

module.exports = { calculateProfileCompletion };
