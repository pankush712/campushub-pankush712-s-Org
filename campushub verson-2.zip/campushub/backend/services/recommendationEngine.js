function getSkillGaps(skills) {
  return skills
    .map((s) => ({ ...s, gap: s.target_level - s.current_level }))
    .filter((s) => s.gap > 0)
    .sort((a, b) => b.gap - a.gap);
}

function daysUntil(dateStr) {
  if (!dateStr) return null;
  const target = new Date(dateStr);
  if (Number.isNaN(target.getTime())) return null;
  const now = new Date();
  const diffMs = target.setHours(0, 0, 0, 0) - now.setHours(0, 0, 0, 0);
  return Math.round(diffMs / (1000 * 60 * 60 * 24));
}

function generateRecommendations({ user, skills, achievements, goals, profileCompletion }) {
  const recommendations = [];
  const gaps = getSkillGaps(skills);

  if (profileCompletion < 100) {
    if (!user.career_goal) {
      recommendations.push({ text: 'Set a career goal on your profile so recommendations can be tailored to it.', reason: 'Profile incomplete: career goal missing' });
    } else if (!user.bio || !user.location) {
      recommendations.push({ text: 'Finish filling out your profile basics (bio, location).', reason: 'Profile incomplete' });
    } else if (!user.school || !user.course) {
      recommendations.push({ text: 'Add your education details to complete your profile.', reason: 'Profile incomplete' });
    }
  }

  if (achievements.length === 0) {
    recommendations.push({ text: 'Add your first achievement to start building your growth timeline.', reason: 'No achievements logged yet' });
  }

  if (gaps.length > 0) {
    const top = gaps[0];
    recommendations.push({ text: `Improve ${top.name} \u2014 you're ${top.gap} level(s) below your target.`, reason: 'Largest skill gap' });
  }

  const notStartedGoals = goals.filter((g) => g.status === 'Not Started');
  if (notStartedGoals.length > 0) {
    recommendations.push({ text: `Start working on your goal: "${notStartedGoals[0].title}".`, reason: 'Goal not started' });
  }

  const soonGoals = goals
    .map((g) => ({ ...g, daysLeft: daysUntil(g.target_date) }))
    .filter((g) => g.daysLeft !== null && g.daysLeft >= 0 && g.daysLeft <= 14 && g.status !== 'Completed');
  if (soonGoals.length > 0) {
    recommendations.push({ text: `"${soonGoals[0].title}" is due in ${soonGoals[0].daysLeft} day(s) \u2014 check your progress.`, reason: 'Goal deadline approaching' });
  }

  const projectAchievements = achievements.filter((a) => a.category === 'Project');
  if (projectAchievements.length === 0) {
    recommendations.push({ text: 'Add a project to your achievements \u2014 projects carry real weight for internships.', reason: 'No projects logged' });
  }

  if (recommendations.length === 0) {
    recommendations.push({ text: 'Your profile is in great shape. Keep logging progress as it happens.', reason: 'All core checks passed' });
  }

  return recommendations.slice(0, 5);
}

function calculateGrowthScore({ profileCompletion, skills, goals, achievements }) {
  const skillAvg = skills.length
    ? skills.reduce((sum, s) => sum + s.current_level / s.target_level, 0) / skills.length
    : 0;
  const goalCompletionRatio = goals.length
    ? goals.filter((g) => g.status === 'Completed').length / goals.length
    : 0;
  const achievementFactor = Math.min(achievements.length / 5, 1);

  const score =
    profileCompletion * 0.3 +
    skillAvg * 100 * 0.3 +
    goalCompletionRatio * 100 * 0.2 +
    achievementFactor * 100 * 0.2;

  return Math.round(score);
}

module.exports = { getSkillGaps, generateRecommendations, calculateGrowthScore, daysUntil };
