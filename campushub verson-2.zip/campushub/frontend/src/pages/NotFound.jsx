import { Link } from 'react-router-dom';

export default function NotFound() {
  return (
    <div className="auth-page">
      <div className="auth-card">
        <h2>Page not found</h2>
        <p><Link to="/">Go back to the dashboard</Link></p>
      </div>
    </div>
  );
}
