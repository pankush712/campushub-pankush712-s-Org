import { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext.jsx';
import { fetchSkills, createSkillRequest, updateSkillRequest, deleteSkillRequest } from '../api/skills.js';
import Card from '../components/common/Card.jsx';
import ProgressBar from '../components/common/ProgressBar.jsx';
import Badge from '../components/common/Badge.jsx';
import Modal from '../components/common/Modal.jsx';
import ConfirmDialog from '../components/common/ConfirmDialog.jsx';
import EmptyState from '../components/common/EmptyState.jsx';
import LoadingSpinner from '../components/common/LoadingSpinner.jsx';

const CATEGORIES = ['Programming', 'Web Development', 'Data Structures', 'Database', 'Communication', 'Leadership', 'Problem Solving', 'Other'];
const LEVEL_LABELS = { 1: 'Beginner', 2: 'Basic', 3: 'Intermediate', 4: 'Advanced', 5: 'Expert' };
const EMPTY_FORM = { name: '', category: 'Programming', current_level: 1, target_level: 3, assessment_score: 0 };

export default function Skills() {
  const { token } = useAuth();
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [modalOpen, setModalOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [form, setForm] = useState(EMPTY_FORM);
  const [confirmId, setConfirmId] = useState(null);

  function load() {
    setLoading(true);
    fetchSkills(token).then(setItems).catch((err) => setError(err.message)).finally(() => setLoading(false));
  }
  useEffect(load, [token]);

  function openCreate() { setForm(EMPTY_FORM); setEditingId(null); setModalOpen(true); }
  function openEdit(item) { setForm(item); setEditingId(item.id); setModalOpen(true); }

  async function handleSubmit(e) {
    e.preventDefault();
    try {
      if (editingId) await updateSkillRequest(token, editingId, form);
      else await createSkillRequest(token, form);
      setModalOpen(false);
      load();
    } catch (err) { setError(err.message); }
  }

  async function handleDelete() {
    try { await deleteSkillRequest(token, confirmId); setConfirmId(null); load(); }
    catch (err) { setError(err.message); }
  }

  const biggestGaps = [...items].sort((a, b) => (b.target_level - b.current_level) - (a.target_level - a.current_level)).slice(0, 3);

  return (
    <div>
      <div className="toolbar">
        <h3>Skills</h3>
        <button className="btn btn-primary" onClick={openCreate}>+ Add Skill</button>
      </div>

      {error && <div className="alert alert-error">{error}</div>}

      {items.length > 0 && (
        <Card title="Largest Skill Gaps">
          <ul className="plain-list">
            {biggestGaps.map((s) => (
              <li key={s.id}>
                <strong>{s.name}</strong> — Current: {s.current_level} · Target: {s.target_level}
                <Badge tone="warn">Gap: {s.target_level - s.current_level}</Badge>
              </li>
            ))}
          </ul>
        </Card>
      )}

      {loading ? (
        <LoadingSpinner />
      ) : items.length === 0 ? (
        <EmptyState title="No skills yet" description="Add a skill to start tracking your progress." />
      ) : (
        <div className="card-grid">
          {items.map((s) => (
            <Card key={s.id}>
              <div className="achievement-head">
                <strong>{s.name}</strong>
                <Badge>{s.category}</Badge>
              </div>
              <ProgressBar value={s.current_level} max={s.target_level} label={`${LEVEL_LABELS[s.current_level]} \u2192 ${LEVEL_LABELS[s.target_level]}`} />
              <div className="card-actions">
                <button className="btn btn-ghost" onClick={() => openEdit(s)}>Edit</button>
                <button className="btn btn-ghost btn-danger-text" onClick={() => setConfirmId(s.id)}>Delete</button>
              </div>
            </Card>
          ))}
        </div>
      )}

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editingId ? 'Edit Skill' : 'Add Skill'}>
        <form onSubmit={handleSubmit} className="form-grid">
          <label className="full-width">
            Skill Name
            <input required value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} />
          </label>
          <label>
            Category
            <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}>
              {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
          </label>
          <label>
            Assessment Score
            <input type="number" min="0" max="100" value={form.assessment_score} onChange={(e) => setForm({ ...form, assessment_score: e.target.value })} />
          </label>
          <label>
            Current Level (1-5)
            <select value={form.current_level} onChange={(e) => setForm({ ...form, current_level: Number(e.target.value) })}>
              {[1, 2, 3, 4, 5].map((n) => <option key={n} value={n}>{n} - {LEVEL_LABELS[n]}</option>)}
            </select>
          </label>
          <label>
            Target Level (1-5)
            <select value={form.target_level} onChange={(e) => setForm({ ...form, target_level: Number(e.target.value) })}>
              {[1, 2, 3, 4, 5].map((n) => <option key={n} value={n}>{n} - {LEVEL_LABELS[n]}</option>)}
            </select>
          </label>
          <div className="form-actions full-width">
            <button type="button" className="btn btn-ghost" onClick={() => setModalOpen(false)}>Cancel</button>
            <button type="submit" className="btn btn-primary">{editingId ? 'Save Changes' : 'Add Skill'}</button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog open={confirmId !== null} title="Delete skill?" message="This action cannot be undone." onCancel={() => setConfirmId(null)} onConfirm={handleDelete} />
    </div>
  );
}
