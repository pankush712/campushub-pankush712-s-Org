import { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext.jsx';
import { fetchGoals, createGoalRequest, updateGoalRequest, deleteGoalRequest } from '../api/goals.js';
import Card from '../components/common/Card.jsx';
import ProgressBar from '../components/common/ProgressBar.jsx';
import Badge from '../components/common/Badge.jsx';
import Modal from '../components/common/Modal.jsx';
import ConfirmDialog from '../components/common/ConfirmDialog.jsx';
import EmptyState from '../components/common/EmptyState.jsx';
import LoadingSpinner from '../components/common/LoadingSpinner.jsx';

const TYPES = ['Career', 'Academic', 'Technical', 'Personal', 'Project'];
const STATUSES = ['Not Started', 'In Progress', 'Completed'];
const PRIORITIES = ['Low', 'Medium', 'High'];
const EMPTY_FORM = { title: '', type: 'Career', description: '', target_date: '', priority: 'Medium', status: 'Not Started', related_skills: '', progress: 0 };

export default function Goals() {
  const { token } = useAuth();
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [statusFilter, setStatusFilter] = useState('');
  const [modalOpen, setModalOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [form, setForm] = useState(EMPTY_FORM);
  const [confirmId, setConfirmId] = useState(null);

  function load() {
    setLoading(true);
    const params = statusFilter ? { status: statusFilter } : {};
    fetchGoals(token, params).then(setItems).catch((err) => setError(err.message)).finally(() => setLoading(false));
  }
  useEffect(load, [token, statusFilter]);

  function openCreate() { setForm(EMPTY_FORM); setEditingId(null); setModalOpen(true); }
  function openEdit(item) { setForm(item); setEditingId(item.id); setModalOpen(true); }

  async function handleSubmit(e) {
    e.preventDefault();
    try {
      if (editingId) await updateGoalRequest(token, editingId, form);
      else await createGoalRequest(token, form);
      setModalOpen(false);
      load();
    } catch (err) { setError(err.message); }
  }

  async function handleDelete() {
    try { await deleteGoalRequest(token, confirmId); setConfirmId(null); load(); }
    catch (err) { setError(err.message); }
  }

  async function quickUpdateProgress(goal, progress) {
    try {
      const status = progress >= 100 ? 'Completed' : progress > 0 ? 'In Progress' : 'Not Started';
      await updateGoalRequest(token, goal.id, { progress, status });
      load();
    } catch (err) { setError(err.message); }
  }

  return (
    <div>
      <div className="toolbar">
        <select value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
          <option value="">All Statuses</option>
          {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
        </select>
        <button className="btn btn-primary" onClick={openCreate}>+ Add Goal</button>
      </div>

      {error && <div className="alert alert-error">{error}</div>}

      {loading ? (
        <LoadingSpinner />
      ) : items.length === 0 ? (
        <EmptyState title="No goals yet" description="Add a goal to start tracking your progress." />
      ) : (
        <div className="card-grid">
          {items.map((g) => (
            <Card key={g.id}>
              <div className="achievement-head">
                <strong>{g.title}</strong>
                <Badge tone={g.priority === 'High' ? 'warn' : 'default'}>{g.priority}</Badge>
              </div>
              <div className="muted">{g.type} · {g.status} · due {g.target_date || 'no date'}</div>
              {g.description && <p className="muted">{g.description}</p>}
              <ProgressBar value={g.progress} label="Progress" />
              <input
                type="range" min="0" max="100" value={g.progress}
                onChange={(e) => quickUpdateProgress(g, Number(e.target.value))}
              />
              <div className="card-actions">
                <button className="btn btn-ghost" onClick={() => openEdit(g)}>Edit</button>
                <button className="btn btn-ghost btn-danger-text" onClick={() => setConfirmId(g.id)}>Delete</button>
              </div>
            </Card>
          ))}
        </div>
      )}

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editingId ? 'Edit Goal' : 'Add Goal'}>
        <form onSubmit={handleSubmit} className="form-grid">
          <label className="full-width">
            Title
            <input required value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
          </label>
          <label>
            Type
            <select value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })}>
              {TYPES.map((t) => <option key={t} value={t}>{t}</option>)}
            </select>
          </label>
          <label>
            Priority
            <select value={form.priority} onChange={(e) => setForm({ ...form, priority: e.target.value })}>
              {PRIORITIES.map((p) => <option key={p} value={p}>{p}</option>)}
            </select>
          </label>
          <label>
            Status
            <select value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value })}>
              {STATUSES.map((s) => <option key={s} value={s}>{s}</option>)}
            </select>
          </label>
          <label>
            Target Date
            <input type="date" value={form.target_date || ''} onChange={(e) => setForm({ ...form, target_date: e.target.value })} />
          </label>
          <label>
            Related Skills (comma separated)
            <input value={form.related_skills || ''} onChange={(e) => setForm({ ...form, related_skills: e.target.value })} />
          </label>
          <label className="full-width">
            Description
            <textarea value={form.description || ''} onChange={(e) => setForm({ ...form, description: e.target.value })} />
          </label>
          <div className="form-actions full-width">
            <button type="button" className="btn btn-ghost" onClick={() => setModalOpen(false)}>Cancel</button>
            <button type="submit" className="btn btn-primary">{editingId ? 'Save Changes' : 'Add Goal'}</button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog open={confirmId !== null} title="Delete goal?" message="This action cannot be undone." onCancel={() => setConfirmId(null)} onConfirm={handleDelete} />
    </div>
  );
}
