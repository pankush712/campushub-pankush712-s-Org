import { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext.jsx';
import { fetchDashboard } from '../api/dashboard.js';
import Card from '../components/common/Card.jsx';
import ProgressBar from '../components/common/ProgressBar.jsx';
import Badge from '../components/common/Badge.jsx';
import LoadingSpinner from '../components/common/LoadingSpinner.jsx';
import EmptyState from '../components/common/EmptyState.jsx';

export default function Dashboard() {
  const { token } = useAuth();
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let active = true;
    setLoading(true);
    fetchDashboard(token)
      .then((d) => { if (active) setData(d); })
      .catch((err) => { if (active) setError(err.message); })
      .finally(() => { if (active) setLoading(false); });
    return () => { active = false; };
  }, [token]);

  if (loading) return <LoadingSpinner label="Loading your dashboard..." />;
  if (error) return <div className="alert alert-error">{error}</div>;
  if (!data) return null;

  return (
    <div className="dashboard-grid">
      <Card className="span-2">
        <div className="dashboard-header">
          <div>
            <h2>Welcome back, {data.studentName.split(' ')[0]}</h2>
            <p className="muted">Career goal: {data.careerGoal}</p>
          </div>
          <div className="dashboard-score">
            <div className="score-value">{data.growthScore}</div>
            <div className="score-label">Growth Score</div>
          </div>
        </div>
        <ProgressBar value={data.profileCompletion} label="Profile completion" />
      </Card>

      <Card title="Your Next Steps" className="span-2">
        {data.nextSteps.length === 0 ? (
          <EmptyState title="Nothing pending" description="You're all caught up." />
        ) : (
          <ul className="next-steps-list">
            {data.nextSteps.map((step, i) => (
              <li key={i}>
                <span>{step.text}</span>
                <Badge tone="muted">{step.reason}</Badge>
              </li>
            ))}
          </ul>
        )}
      </Card>

      <Card title="Skill Progress">
        {data.skillProgress.length === 0 ? (
          <EmptyState title="No skills yet" description="Add skills to see your progress here." />
        ) : (
          data.skillProgress.map((s) => (
            <ProgressBar key={s.id} value={s.current_level} max={s.target_level} label={s.name} />
          ))
        )}
      </Card>

      <Card title="Top Skill Gaps">
        {data.topSkillGaps.length === 0 ? (
          <EmptyState title="No gaps found" description="Your current and target levels are aligned." />
        ) : (
          <ul className="plain-list">
            {data.topSkillGaps.map((s) => (
              <li key={s.id}>
                <strong>{s.name}</strong> — current {s.current_level}, target {s.target_level}
                <Badge tone="warn">Gap: {s.gap}</Badge>
              </li>
            ))}
          </ul>
        )}
      </Card>

      <Card title="Recent Achievements">
        {data.recentAchievements.length === 0 ? (
          <EmptyState title="No achievements yet" description="Log your first achievement to start your timeline." />
        ) : (
          <ul className="plain-list">
            {data.recentAchievements.map((a) => (
              <li key={a.id}>
                <strong>{a.title}</strong>
                <Badge>{a.category}</Badge>
                <span className="muted"> {a.date}</span>
              </li>
            ))}
          </ul>
        )}
      </Card>

      <Card title="Upcoming Goals">
        {data.upcomingGoals.length === 0 ? (
          <EmptyState title="No active goals" description="Add a goal to start tracking progress." />
        ) : (
          data.upcomingGoals.map((g) => (
            <div key={g.id} className="goal-row">
              <div>
                <strong>{g.title}</strong>
                <div className="muted">{g.type} · due {g.target_date || 'no date'}</div>
              </div>
              <ProgressBar value={g.progress} label="" />
            </div>
          ))
        )}
      </Card>

      <Card title="Stats" className="span-2">
        <div className="stats-row">
          <div><div className="stat-value">{data.stats.totalSkills}</div><div className="stat-label">Skills</div></div>
          <div><div className="stat-value">{data.stats.totalAchievements}</div><div className="stat-label">Achievements</div></div>
          <div><div className="stat-value">{data.stats.totalGoals}</div><div className="stat-label">Goals</div></div>
          <div><div className="stat-value">{data.stats.goalsCompleted}</div><div className="stat-label">Completed</div></div>
        </div>
      </Card>
    </div>
  );
}
