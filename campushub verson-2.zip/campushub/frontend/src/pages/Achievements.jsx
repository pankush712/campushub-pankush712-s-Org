import { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext.jsx';
import {
  fetchAchievements, createAchievementRequest, updateAchievementRequest, deleteAchievementRequest
} from '../api/achievements.js';
import Card from '../components/common/Card.jsx';
import Badge from '../components/common/Badge.jsx';
import Modal from '../components/common/Modal.jsx';
import ConfirmDialog from '../components/common/ConfirmDialog.jsx';
import EmptyState from '../components/common/EmptyState.jsx';
import LoadingSpinner from '../components/common/LoadingSpinner.jsx';

const CATEGORIES = ['Academic', 'Certification', 'Project', 'Competition', 'Hackathon', 'Internship', 'Volunteering', 'Extracurricular', 'Leadership', 'Other'];

const EMPTY_FORM = { title: '', category: 'Academic', description: '', date: '', organization: '', evidence_link: '', certificate_link: '', skills: '' };

export default function Achievements() {
  const { token } = useAuth();
  const [items, setItems] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  const [search, setSearch] = useState('');
  const [categoryFilter, setCategoryFilter] = useState('');
  const [sort, setSort] = useState('newest');
  const [modalOpen, setModalOpen] = useState(false);
  const [editingId, setEditingId] = useState(null);
  const [form, setForm] = useState(EMPTY_FORM);
  const [confirmId, setConfirmId] = useState(null);

  function load() {
    setLoading(true);
    const params = {};
    if (categoryFilter) params.category = categoryFilter;
    if (search) params.search = search;
    if (sort) params.sort = sort;
    fetchAchievements(token, params)
      .then(setItems)
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }

  useEffect(load, [token, categoryFilter, sort]);

  function handleSearchSubmit(e) {
    e.preventDefault();
    load();
  }

  function openCreate() {
    setForm(EMPTY_FORM);
    setEditingId(null);
    setModalOpen(true);
  }

  function openEdit(item) {
    setForm(item);
    setEditingId(item.id);
    setModalOpen(true);
  }

  async function handleSubmit(e) {
    e.preventDefault();
    try {
      if (editingId) {
        await updateAchievementRequest(token, editingId, form);
      } else {
        await createAchievementRequest(token, form);
      }
      setModalOpen(false);
      load();
    } catch (err) {
      setError(err.message);
    }
  }

  async function handleDelete() {
    try {
      await deleteAchievementRequest(token, confirmId);
      setConfirmId(null);
      load();
    } catch (err) {
      setError(err.message);
    }
  }

  const byYear = items.reduce((acc, a) => {
    const year = (a.date || '').slice(0, 4) || 'Undated';
    acc[year] = acc[year] || [];
    acc[year].push(a);
    return acc;
  }, {});
  const years = Object.keys(byYear).sort().reverse();

  return (
    <div>
      <div className="toolbar">
        <form onSubmit={handleSearchSubmit} className="toolbar-search">
          <input placeholder="Search achievements..." value={search} onChange={(e) => setSearch(e.target.value)} />
          <button className="btn btn-ghost" type="submit">Search</button>
        </form>
        <select value={categoryFilter} onChange={(e) => setCategoryFilter(e.target.value)}>
          <option value="">All Categories</option>
          {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
        </select>
        <select value={sort} onChange={(e) => setSort(e.target.value)}>
          <option value="newest">Newest first</option>
          <option value="oldest">Oldest first</option>
        </select>
        <button className="btn btn-primary" onClick={openCreate}>+ Add Achievement</button>
      </div>

      {error && <div className="alert alert-error">{error}</div>}

      {loading ? (
        <LoadingSpinner />
      ) : items.length === 0 ? (
        <EmptyState title="No achievements found" description="Add your first achievement to start your timeline." />
      ) : (
        <div className="timeline">
          {years.map((year) => (
            <div key={year} className="timeline-year">
              <h3>{year}</h3>
              <div className="timeline-items">
                {byYear[year].map((a) => (
                  <Card key={a.id} className="achievement-card">
                    <div className="achievement-head">
                      <strong>{a.title}</strong>
                      <Badge>{a.category}</Badge>
                    </div>
                    {a.description && <p className="muted">{a.description}</p>}
                    <div className="achievement-meta">
                      {a.organization && <span>{a.organization}</span>}
                      {a.date && <span>{a.date}</span>}
                      {a.skills && <span>Skills: {a.skills}</span>}
                    </div>
                    <div className="card-actions">
                      <button className="btn btn-ghost" onClick={() => openEdit(a)}>Edit</button>
                      <button className="btn btn-ghost btn-danger-text" onClick={() => setConfirmId(a.id)}>Delete</button>
                    </div>
                  </Card>
                ))}
              </div>
            </div>
          ))}
        </div>
      )}

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title={editingId ? 'Edit Achievement' : 'Add Achievement'}>
        <form onSubmit={handleSubmit} className="form-grid">
          <label className="full-width">
            Title
            <input required value={form.title} onChange={(e) => setForm({ ...form, title: e.target.value })} />
          </label>
          <label>
            Category
            <select value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })}>
              {CATEGORIES.map((c) => <option key={c} value={c}>{c}</option>)}
            </select>
          </label>
          <label>
            Date
            <input type="date" value={form.date || ''} onChange={(e) => setForm({ ...form, date: e.target.value })} />
          </label>
          <label>
            Organization
            <input value={form.organization || ''} onChange={(e) => setForm({ ...form, organization: e.target.value })} />
          </label>
          <label>
            Skills (comma separated)
            <input value={form.skills || ''} onChange={(e) => setForm({ ...form, skills: e.target.value })} />
          </label>
          <label>
            Evidence Link
            <input value={form.evidence_link || ''} onChange={(e) => setForm({ ...form, evidence_link: e.target.value })} />
          </label>
          <label>
            Certificate Link
            <input value={form.certificate_link || ''} onChange={(e) => setForm({ ...form, certificate_link: e.target.value })} />
          </label>
          <label className="full-width">
            Description
            <textarea value={form.description || ''} onChange={(e) => setForm({ ...form, description: e.target.value })} />
          </label>
          <div className="form-actions full-width">
            <button type="button" className="btn btn-ghost" onClick={() => setModalOpen(false)}>Cancel</button>
            <button type="submit" className="btn btn-primary">{editingId ? 'Save Changes' : 'Add Achievement'}</button>
          </div>
        </form>
      </Modal>

      <ConfirmDialog
        open={confirmId !== null}
        title="Delete achievement?"
        message="This action cannot be undone."
        onCancel={() => setConfirmId(null)}
        onConfirm={handleDelete}
      />
    </div>
  );
}
