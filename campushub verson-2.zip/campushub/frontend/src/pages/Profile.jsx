import { useEffect, useState } from 'react';
import { useAuth } from '../context/AuthContext.jsx';
import { fetchProfile, updateProfileRequest } from '../api/profile.js';
import Card from '../components/common/Card.jsx';
import ProgressBar from '../components/common/ProgressBar.jsx';
import LoadingSpinner from '../components/common/LoadingSpinner.jsx';

const FIELDS = [
  ['name', 'Name'], ['email', 'Email'], ['school', 'School / College'], ['course', 'Course'],
  ['year', 'Year'], ['career_goal', 'Career Goal'], ['location', 'Location'],
  ['linkedin_url', 'LinkedIn URL'], ['github_url', 'GitHub URL'], ['interests', 'Interests']
];

export default function Profile() {
  const { token } = useAuth();
  const [profile, setProfile] = useState(null);
  const [form, setForm] = useState({});
  const [editing, setEditing] = useState(false);
  const [saving, setSaving] = useState(false);
  const [error, setError] = useState(null);
  const [success, setSuccess] = useState(null);
  const [loading, setLoading] = useState(true);

  function load() {
    setLoading(true);
    fetchProfile(token)
      .then((p) => { setProfile(p); setForm(p); })
      .catch((err) => setError(err.message))
      .finally(() => setLoading(false));
  }

  useEffect(load, [token]);

  function handleChange(field, value) {
    setForm((f) => ({ ...f, [field]: value }));
  }

  async function handleSave(e) {
    e.preventDefault();
    setSaving(true);
    setError(null);
    setSuccess(null);
    try {
      const updated = await updateProfileRequest(token, form);
      setProfile((p) => ({ ...p, ...updated }));
      setEditing(false);
      setSuccess('Profile updated.');
    } catch (err) {
      setError(err.message);
    } finally {
      setSaving(false);
    }
  }

  if (loading) return <LoadingSpinner label="Loading profile..." />;
  if (!profile) return <div className="alert alert-error">{error}</div>;

  return (
    <div className="profile-grid">
      <Card>
        <div className="profile-photo-placeholder">{profile.name?.[0]?.toUpperCase() || '?'}</div>
        <ProgressBar value={profile.profileCompletion} label="Profile completion" />
        <p className="muted">{profile.bio || 'No bio added yet.'}</p>
      </Card>

      <Card title={editing ? 'Edit Profile' : 'Profile Details'} className="span-2">
        {error && <div className="alert alert-error">{error}</div>}
        {success && <div className="alert alert-success">{success}</div>}

        {!editing ? (
          <>
            <dl className="detail-list">
              {FIELDS.map(([key, label]) => (
                <div key={key}>
                  <dt>{label}</dt>
                  <dd>{profile[key] || <span className="muted">Not set</span>}</dd>
                </div>
              ))}
            </dl>
            <button className="btn btn-primary" onClick={() => { setForm(profile); setEditing(true); }}>
              Edit Profile
            </button>
          </>
        ) : (
          <form onSubmit={handleSave} className="form-grid">
            {FIELDS.filter(([key]) => key !== 'email').map(([key, label]) => (
              key === 'interests' ? (
                <label key={key} className="full-width">
                  {label}
                  <textarea value={form[key] || ''} onChange={(e) => handleChange(key, e.target.value)} />
                </label>
              ) : (
                <label key={key}>
                  {label}
                  <input value={form[key] || ''} onChange={(e) => handleChange(key, e.target.value)} />
                </label>
              )
            ))}
            <label className="full-width">
              Bio
              <textarea value={form.bio || ''} onChange={(e) => handleChange('bio', e.target.value)} />
            </label>
            <div className="form-actions full-width">
              <button type="button" className="btn btn-ghost" onClick={() => setEditing(false)}>Cancel</button>
              <button type="submit" className="btn btn-primary" disabled={saving}>
                {saving ? 'Saving...' : 'Save Changes'}
              </button>
            </div>
          </form>
        )}
      </Card>
    </div>
  );
}
