import request from './client.js';

export function fetchProfile(token) {
  return request('/profile', { token });
}

export function updateProfileRequest(token, updates) {
  return request('/profile', { method: 'PUT', body: updates, token });
}
