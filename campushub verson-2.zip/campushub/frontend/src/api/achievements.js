import request from './client.js';

export function fetchAchievements(token, params = {}) {
  const query = new URLSearchParams(params).toString();
  return request(`/achievements${query ? `?${query}` : ''}`, { token });
}
export function createAchievementRequest(token, data) {
  return request('/achievements', { method: 'POST', body: data, token });
}
export function updateAchievementRequest(token, id, data) {
  return request(`/achievements/${id}`, { method: 'PUT', body: data, token });
}
export function deleteAchievementRequest(token, id) {
  return request(`/achievements/${id}`, { method: 'DELETE', token });
}
