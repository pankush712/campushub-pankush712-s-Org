import request from './client.js';

export function fetchGoals(token, params = {}) {
  const query = new URLSearchParams(params).toString();
  return request(`/goals${query ? `?${query}` : ''}`, { token });
}
export function createGoalRequest(token, data) {
  return request('/goals', { method: 'POST', body: data, token });
}
export function updateGoalRequest(token, id, data) {
  return request(`/goals/${id}`, { method: 'PUT', body: data, token });
}
export function deleteGoalRequest(token, id) {
  return request(`/goals/${id}`, { method: 'DELETE', token });
}
