import request from './client.js';

export function fetchDashboard(token) {
  return request('/dashboard', { token });
}
