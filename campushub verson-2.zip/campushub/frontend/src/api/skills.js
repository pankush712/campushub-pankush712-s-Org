import request from './client.js';

export function fetchSkills(token) {
  return request('/skills', { token });
}
export function createSkillRequest(token, data) {
  return request('/skills', { method: 'POST', body: data, token });
}
export function updateSkillRequest(token, id, data) {
  return request(`/skills/${id}`, { method: 'PUT', body: data, token });
}
export function deleteSkillRequest(token, id) {
  return request(`/skills/${id}`, { method: 'DELETE', token });
}
