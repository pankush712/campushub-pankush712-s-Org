import request from './client.js';

export function loginRequest(email, password) {
  return request('/auth/login', { method: 'POST', body: { email, password } });
}

export function registerRequest(name, email, password) {
  return request('/auth/register', { method: 'POST', body: { name, email, password } });
}
