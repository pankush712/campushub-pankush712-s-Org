import { Outlet, useLocation } from 'react-router-dom';
import Sidebar from './Sidebar.jsx';
import Topbar from './Topbar.jsx';

const titles = {
  '/': 'Dashboard',
  '/profile': 'My Profile',
  '/achievements': 'Achievements',
  '/skills': 'Skills',
  '/goals': 'Goals'
};

export default function Layout() {
  const location = useLocation();
  const title = titles[location.pathname] || 'CampusHub';

  return (
    <div className="app-shell">
      <Sidebar />
      <div className="app-main">
        <Topbar title={title} />
        <main className="app-content">
          <Outlet />
        </main>
      </div>
    </div>
  );
}
