import { NavLink } from 'react-router-dom';

const links = [
  { to: '/', label: 'Dashboard', end: true },
  { to: '/profile', label: 'My Profile' },
  { to: '/achievements', label: 'Achievements' },
  { to: '/skills', label: 'Skills' },
  { to: '/goals', label: 'Goals' }
];

export default function Sidebar() {
  return (
    <aside className="sidebar">
      <div className="sidebar-brand">CampusHub</div>
      <nav className="sidebar-nav">
        {links.map((link) => (
          <NavLink
            key={link.to}
            to={link.to}
            end={link.end}
            className={({ isActive }) => `sidebar-link${isActive ? ' active' : ''}`}
          >
            {link.label}
          </NavLink>
        ))}
      </nav>
      <div className="sidebar-note">
        More modules (Resources, Opportunities, Study Planner, Career Roadmap) are planned for a later phase.
      </div>
    </aside>
  );
}
